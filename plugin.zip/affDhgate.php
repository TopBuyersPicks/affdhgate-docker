<?php
/*
Plugin Name: affDhgate
Description: Affiliate automation plugin for DHgate with GitHub and Render deploy support.
Version: 1.6.2
Author: TopBuyersPicks
*/

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'affdhgate_menu');
function affdhgate_menu() {
    add_menu_page('affDhgate', 'affDhgate', 'manage_options', 'affdhgate', 'affdhgate_dashboard');
        add_submenu_page('affdhgate', 'Deploy Project', 'Deploy Project', 'manage_options', 'affdhgate_deploy', 'affdhgate_deploy_page');
        }

        function affdhgate_dashboard() {
            echo "<h2>affDhgate Plugin v1.6.2</h2><p>Main dashboard coming soon...</p>";
            }

            function affdhgate_deploy_page() {
                if (isset($_POST['deploy_submit'])) {
                        $msg = affdhgate_upload_and_deploy();
                                echo "<div style='padding:10px;background:#fff;border:1px solid #ccc;'><strong>Result:</strong><br>$msg</div>";
                                    }

                                        ?>
                                            <h2>Deploy affDhgate Project</h2>
                                                <form method="post">
                                                        <p><input type="submit" name="deploy_submit" class="button-primary" value="Upload Plugin & Deploy to Render"></p>
                                                            </form>
                                                                <?php
                                                                }

                                                                function affdhgate_upload_and_deploy() {
                                                                    $github_token = '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';
                                                                        $github_repo = 'TopBuyersPicks/affdhgate-docker';
                                                                            $github_api_url = "https://api.github.com/repos/$github_repo/contents/plugin.zip";

                                                                                $plugin_dir = plugin_dir_path(__FILE__);
                                                                                    $zip_path = $plugin_dir . 'plugin.zip';

                                                                                        $zip = new ZipArchive;
                                                                                            if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                                                                                                    $files = new RecursiveIteratorIterator(
                                                                                                                new RecursiveDirectoryIterator($plugin_dir),
                                                                                                                            RecursiveIteratorIterator::LEAVES_ONLY
                                                                                                                                    );
                                                                                                                                            foreach ($files as $name => $file) {
                                                                                                                                                        if (!$file->isDir() && strpos($file, 'plugin.zip') === false) {
                                                                                                                                                                        $filePath = $file->getRealPath();
                                                                                                                                                                                        $relativePath = substr($filePath, strlen($plugin_dir));
                                                                                                                                                                                                        $zip->addFile($filePath, $relativePath);
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                    $zip->close();
                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                return "Error creating plugin.zip.";
                                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                                        $content = file_get_contents($zip_path);
                                                                                                                                                                                                                                                            $base64 = base64_encode($content);

                                                                                                                                                                                                                                                                $ch = curl_init($github_api_url);
                                                                                                                                                                                                                                                                    curl_setopt($ch, CURLOPT_USERAGENT, 'affDhgatePlugin');
                                                                                                                                                                                                                                                                        curl_setopt($ch, CURLOPT_HTTPHEADER, [
                                                                                                                                                                                                                                                                                "Authorization: token $github_token",
                                                                                                                                                                                                                                                                                        "Content-Type: application/json"
                                                                                                                                                                                                                                                                                            ]);
                                                                                                                                                                                                                                                                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                                                                                                                                                                                                                                                                                                    $check = json_decode(curl_exec($ch), true);
                                                                                                                                                                                                                                                                                                        $sha = $check['sha'] ?? null;
                                                                                                                                                                                                                                                                                                            curl_close($ch);

                                                                                                                                                                                                                                                                                                                $payload = json_encode([
                                                                                                                                                                                                                                                                                                                        "message" => "Upload plugin.zip",
                                                                                                                                                                                                                                                                                                                                "content" => $base64,
                                                                                                                                                                                                                                                                                                                                        "branch" => "main",
                                                                                                                                                                                                                                                                                                                                                "sha" => $sha
                                                                                                                                                                                                                                                                                                                                                    ]);

                                                                                                                                                                                                                                                                                                                                                        $ch = curl_init($github_api_url);
                                                                                                                                                                                                                                                                                                                                                            curl_setopt($ch, CURLOPT_USERAGENT, 'affDhgatePlugin');
                                                                                                                                                                                                                                                                                                                                                                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                                                                                                                                                                                                                                                                                                                                                                        "Authorization: token $github_token",
                                                                                                                                                                                                                                                                                                                                                                                "Content-Type: application/json"
                                                                                                                                                                                                                                                                                                                                                                                    ]);
                                                                                                                                                                                                                                                                                                                                                                                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
                                                                                                                                                                                                                                                                                                                                                                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                                                                                                                                                                                                                                                                                                                                                                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                                                                                                                                                                                                                                                                                                                                                                                                    $result = curl_exec($ch);
                                                                                                                                                                                                                                                                                                                                                                                                        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                                                                                                                                                                                                                                                                                                                                                                                                            curl_close($ch);

                                                                                                                                                                                                                                                                                                                                                                                                                if ($http_code === 201 || $http_code === 200) {
                                                                                                                                                                                                                                                                                                                                                                                                                        return "Plugin uploaded to GitHub successfully. Now deploy manually using Render: <a href='https://dashboard.render.com/' target='_blank'>Go to Render Dashboard</a>";
                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                    return "Error uploading to GitHub. HTTP $http_code. Response: <pre>$result</pre>";
                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                        }